package Simulation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Beispieltest {


    @Test
    void additionTest() {
        int result = 2 + 3;
        assertEquals(5, result);
    }


}
